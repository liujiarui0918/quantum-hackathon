# Quantum Hackathon Demo Report

## Problem

- Name: sample_assignment
- Source: data\sample_problem.json
- Sense: maximize
- Logical variables: 5
- QUBO bits: 8

## Best Solution

```json
{
  "bitstring": "00110000",
  "bits": [
    0,
    0,
    1,
    1,
    0,
    0,
    0,
    0
  ],
  "logical_solution": {
    "model_a": 0,
    "model_b": 0,
    "model_c": 1,
    "boost_x": 1,
    "boost_y": 0
  },
  "objective_value": 11.0,
  "qubo_energy": -11.0,
  "penalty_energy": 0.0,
  "is_feasible": true,
  "total_violation": 0.0,
  "num_occurrences": 1,
  "source_backend": "exact",
  "constraint_violations": []
}
```

## Solver Benchmark

| solver | status | best_feasible_objective | best_feasible_bitstring | feasible_sample_ratio | total_ms |
| --- | --- | --- | --- | --- | --- |
| exact | ran | 11.0 | 00110000 | 0.28125 | 21.648099999993065 |
| simulated_annealing | ran | 11.0 | 10001000 | 0.6333333333333333 | 764.1825999999128 |
| qaoa_shot_simulator | ran | 11.0 | 01011000 | 0.465 | 343.144 |
| constrained_qaoa_metadata_mvp | ran | 11.0 | 00110000 | 0.28125 | 35.509 |

## Quantum Circuit Implementation

- Ansatz: standard_qaoa_x_mixer
- Backend: local_statevector_optimizer_plus_shot_sampler
- Qubits: 8
- Layers: 1
- Cost unitary: exp(-i gamma C) from QUBO-to-Ising Hamiltonian
- Mixer unitary: exp(-i beta sum_i X_i)
- Gate count estimate: {'h': 8, 'rz_per_layer': 8, 'rzz_per_layer': 28, 'rx_per_layer': 8}

## Reproducibility

- Seed: 7
- Python: 3.12.10
- Total runtime ms: 1613.88
