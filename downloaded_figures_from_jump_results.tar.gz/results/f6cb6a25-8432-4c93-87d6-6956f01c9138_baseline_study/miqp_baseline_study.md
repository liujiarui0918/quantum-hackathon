# MIQP Baseline Study

| instance | method | family | objective | official | gap_percent | feasible | runtime_ms | search_bits | qaoa_qubits | candidates_evaluated |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| miqp_sample_A | zero_x_lp | classical_baseline | 7.275696 | 106.094636 | 93.142258 | True | 1035.569 | 0 | 0 | 1 |
| miqp_sample_A | marginal_greedy_lp | classical_baseline | 97.720843 | 106.094636 | 7.892758 | True | 29.113 | 15 | 0 | 15 |
| miqp_sample_A | structural_warm_start_lp | learning_guided_baseline | 97.720843 | 106.094636 | 7.892758 | True | 15.016 | 15 | 0 | 1 |
| miqp_sample_A | random_repair_lp | classical_stochastic | 105.090577 | 106.094636 | 0.946381 | True | 306.854 | 15 | 0 | 96 |
| miqp_sample_A | genetic_repair_lp | classical_metaheuristic | 106.094636 | 106.094636 | 0.0 | True | 250.499 | 15 | 0 | 61 |
| miqp_sample_A | binary_pso_repair_lp | classical_metaheuristic | 106.094636 | 106.094636 | 0.0 | True | 548.48 | 15 | 0 | 148 |
| miqp_sample_A | exact_binary_lp | classical_exact | 106.094636 | 106.094636 | 0.0 | True | 4217.714 | 15 | 0 | 1152 |
| miqp_sample_A | global_binary_sa_lp | classical_annealing | 105.090577 | 106.094636 | 0.946381 | True | 3543.171 | 16 | 0 | 9 |
| miqp_sample_A | global_learning_guided_lp | learning_guided_baseline | 98.547928 | 106.094636 | 7.113185 | True | 79.707 | 16 | 0 | 3 |
| miqp_sample_A | block_sa_lp | classical_annealing | 105.090577 | 106.094636 | 0.946381 | True | 1288.433 | 11 | 0 | 8 |
| miqp_sample_A | block_learning_guided_lp | learning_guided_baseline | 98.547928 | 106.094636 | 7.113185 | True | 29.433 | 11 | 0 | 3 |
| miqp_sample_A | block_qaoa_lp | quantum_model | 105.090577 | 106.094636 | 0.946381 | True | 4841.882 | 10 | 10 | 137 |
| miqp_sample_A | miqp_aware_route7 | proposed_hybrid_quantum | 106.094636 | 106.094636 | 0.0 | True | 2128.857 | 12 | 0 | 1152 |
| miqp_sample_A | official_reference | reference | 106.094636 | 106.094636 | 0.0 | True | 0.0 | 0 | 0 | 0 |

Gap is `(official - objective) / abs(official) * 100` because the task is maximization.
Peak memory is Python heap measured by `tracemalloc`, so native LP/BLAS memory is not fully counted.
